
  function redirect() {
  var textValue = document.getElementById("imagetype").value;
  if(textValue == "Image Preview")
    {
        location.href = "preview.html";
    }
    else if(textValue == "Image Rollover")
    {
      location.href = "rollover.html";
    }
    else if(textValue == "Image SlideShow"){
        
        location.href = "slideshow.html"
    }
    else
    {
      alert("Invalid Input");
    }

}
function myFunction() {
  alert("You have the following choices 1. image rollowver 2 Image preview 3. Image Slideshow. Choose the option from the form below")
}